<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <!--Here is where all the Materalize CSS stuff goes -->

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/css/materialize.min.css">

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>

    <!--End of Materialize CSS-->
    <title>Leaderboard</title>


    <link rel="stylesheet" href="css/reset.css">


<!--Link to Google Fonts: Roboto 100-->
<link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto:100,400,400i" rel="stylesheet">
        <link rel="stylesheet" href="css/style.css">





  </head>

  <body>

<?php

function newPerson($name,$points){
?>

<div class="row">

<div class="col s7 offset-s3 hoverable person">

<div class="col s1">
<div class="js-card" data-offset="2">
<span class="shine"></span>
<div class="card-inner has-gradient" data-layer="1" data-offset="4"></div>
<div class="card-inner has-mountain" data-layer="2" data-offset="8"></div>
<div class="card-inner has-snow" data-layer="3" data-offset="12"></div>
</div> <!--End of the js-card div-->

</div> <!--End of the cols1 div-->

<div class="col s9">
  <p class="name">Josh Feinsilber</p>
  <p class="desc">This is the description of whoever has the amazing title of being on the leaderboard. This could include their location, their age, or any other information. I don't know if you have a bio in OneChimp but it could go here. Otherwise, this is going to be a pretty boring paragraph. OneChimp for life!</p>
</div> <!--End of cols7 div-->



<div class="col s2" id="points">
<p id="number1" class="number">123</p>
<p class="pointstext">points</p>
</div> <!--End of col s2 div-->

</div> <!--End of the cols7 offset-s3 div-->

</div> <!--End of row div-->


<?php



}

newPerson('Josh','42');
newPerson('Mark','42');

 ?>




        <!--My jQuery add-->
            <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<!--My Javascipt add-->
                <script src="js/index.js"></script>



  </body>
</html>
