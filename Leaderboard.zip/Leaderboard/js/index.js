$(document).ready(function(){


  	$.fn.jQuerySimpleCounter = function( options ) {
  	    var settings = $.extend({
  	        start:  0,
  	        end:    100,
  	        easing: 'swing',
  	        duration: 400,
  	        complete: ''
  	    }, options );

  	    var thisElement = $(this);

  	    $({count: settings.start}).animate({count: settings.end}, {
  			duration: settings.duration,
  			easing: settings.easing,
  			step: function() {
  				var mathCount = Math.ceil(this.count);
  				thisElement.text(mathCount);
  			},
  			complete: settings.complete
  		});
  	};


  $('#number1').jQuerySimpleCounter({end: 123,duration: 4000});




    	/* AUTHOR LINK */
       $('.about-me-img').hover(function(){
              $('.authorWindowWrapper').stop().fadeIn('fast').find('p').addClass('trans');
          }, function(){
              $('.authorWindowWrapper').stop().fadeOut('fast').find('p').removeClass('trans');
          });



  var $poster = $('.js-card'),
      $shine = $('.shine'),
      $layer = $('.card-inner'),
      w = $(window).width(), //window width
      h = $(window).height(); //window height

  $(window).on('mousemove', function(e) {
    var offsetX = 0.5 - e.pageX / w, //cursor position X
        offsetY = 0.5 - e.pageY / h, //cursor position Y
        dy = e.pageY - h / 2, //@h/2 = center of poster
        dx = e.pageX - w / 2, //@w/2 = center of poster
        theta = Math.atan2(dy, dx), //angle between cursor and center of poster in RAD
        angle = theta * 180 / Math.PI - 90, //convert rad in degrees
        offsetPoster = $poster.data('offset'),
        transformPoster = 'translate3d(0, ' + -offsetX * offsetPoster + 'px, 0) rotateX(' + (-offsetY * offsetPoster) + 'deg) rotateY(' + (offsetX * (offsetPoster * 2)) + 'deg)'; //poster transform

    //get angle between 0-360
    if (angle < 0) {
      angle = angle + 360;
    }

    //gradient angle and opacity
    $shine.css('background', 'linear-gradient(' + angle + 'deg, rgba(255,255,255,.1) 0%,rgba(255,255,255,0) 50%)');

    //poster transform
    $poster.css('transform', transformPoster);

    //parallax foreach layer
    $layer.each(function() {
      var $this = $(this),
          offsetLayer = $this.data('offset') || 0,
          transformLayer = 'translate3d(' + offsetX * offsetLayer + 'px, ' + offsetY * offsetLayer + 'px, 0)';

      $this.css('transform', transformLayer);
    });
  });

})
