A Pen created at CodePen.io. You can find this one at http://codepen.io/bosworthco/pen/ZOwjZE.

 Re-creating  the 'card navigation' interaction for Apple TV's homescreen using CSS and JavaScript.